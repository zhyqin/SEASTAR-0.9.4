#!/bin/bash
find ./ -name "*.sh" | xargs chmod 755

